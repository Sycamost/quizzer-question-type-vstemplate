﻿#pragma once
#include "QuestionReader.h"

namespace $question_type_name$Reader
{
	QuestionReader& get();
}