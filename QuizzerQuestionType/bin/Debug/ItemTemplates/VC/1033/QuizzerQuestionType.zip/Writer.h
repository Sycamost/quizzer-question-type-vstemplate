﻿#pragma once
#include "QuestionWriter.h"

namespace $question_type_name$Writer
{
	QuestionWriter& get();
}